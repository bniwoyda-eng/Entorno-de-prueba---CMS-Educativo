export * from './quiz.entity';
